YAMANI.GRAPIC — Projet Android

Ce dossier contient l'application Android et son éditeur HTML local.
L'éditeur est intégré dans l'application : l'utilisation de base ne demande pas Internet.

CONSTRUIRE L'APK SANS ORDINATEUR (depuis un téléphone Android)
1. Extraire ce ZIP dans le gestionnaire de fichiers du téléphone.
2. Créer un dépôt GitHub personnel (New repository), par exemple YAMANI-GRAPIC.
3. Dans le dépôt, choisir Add file > Upload files et envoyer le CONTENU du dossier
   YAMANI_GRAPIC_Android (y compris le dossier caché .github).
4. Valider avec Commit changes sur la branche main.
5. Ouvrir l'onglet Actions du dépôt. Le workflow « Construire APK YAMANI.GRAPIC » démarre.
6. Attendre que l'exécution affiche une coche verte, ouvrir cette exécution et télécharger
   l'artefact « YAMANI-GRAPIC-debug-apk ».
7. Extraire l'archive téléchargée : elle contient app-debug.apk.
8. Ouvrir le fichier APK sur le téléphone et autoriser l'installation depuis cette source
   si Android le demande. N'autoriser que le fichier que vous venez de construire.

IMPORTANT
- Le workflow crée un APK de test (debug), non un APK de publication Play Store.
- Le projet doit être envoyé avec sa structure et le dossier .github/workflows.
- L'APK debug est destiné aux essais. Une version de publication signée sera nécessaire
  avant une distribution publique.
- Identifiant : com.yamani.grapic ; version : 1.0.0 ; Android minimum : 6.0 (API 23).
- Testez l'importation de photos, l'export PNG/JPG/PDF et l'historique sur l'appareil.
